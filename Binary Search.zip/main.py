#Write a program to perform Binary Search for a given set of integer values recursively and non-recursively.

# Recursive
def binary_rec(arr, l, h, x):
    if l > h:
        return -1
    m = (l + h) // 2
    if arr[m] == x:
        return m
    elif arr[m] < x:
        return binary_rec(arr, m + 1, h, x)
    else:
        return binary_rec(arr, l, m - 1, x)


# Non-recursive (Iterative)
def binary_iter(arr, x):
    l, h = 0, len(arr) - 1
    while l <= h:
        m = (l + h) // 2
        if arr[m] == x:
            return m
        elif arr[m] < x:
            l = m + 1
        else:
            h = m - 1
    return -1



# Input
arr = list(map(int, input("Enter sorted numbers: ").split()))
x = int(input("Enter number to search: "))

# Output
print("Non-Recursive:", binary_iter(arr, x))
print("Recursive:", binary_rec(arr, 0, len(arr)-1, x))