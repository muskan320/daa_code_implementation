#Write a program to find Maximum and minimum of the given set of integer values.


n=int(input("Enter the number of elements:"))

numbers=[]
for i in range(n):
  num=int(input())
  numbers.append(num)

maximum=numbers[0]
minimum=numbers[0]

for num in numbers:
    if number[i]>maximum:
      maximum=num
    
    if numbers<minimum:
      minimum=num
    
print("Maximum=",maximum) 
print("Minimum=",minimum)
    
    