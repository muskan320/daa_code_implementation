#Write a program to find minimum cost spanning tree using Kruskal's Algorithm.

# Find parent (for union-find)
def find(parent, i):
    while parent[i] != i:
        i = parent[i]
    return i

# Union of two sets
def union(parent, u, v):
    a = find(parent, u)
    b = find(parent, v)
    parent[a] = b

# Input
n = int(input("Enter number of vertices: "))
e = int(input("Enter number of edges: "))

edges = []
print("Enter edges (u v weight):")
for _ in range(e):
    u, v, w = map(int, input().split())
    edges.append((w, u, v))  # sort by weight

# Sort edges
edges.sort()

parent = [i for i in range(n)]

print("Edge : Weight")
total_cost = 0

# Kruskal's Algorithm
for w, u, v in edges:
    if find(parent, u) != find(parent, v):
        union(parent, u, v)
        print(u, "-", v, ":", w)
        total_cost += w

print("Total cost:", total_cost)