 # Write a program to find minimum cost spanning tree using Prim's Algorithm.


# Number of vertices
n = int(input("Enter number of vertices: "))

# Adjacency matrix input
print("Enter the adjacency matrix:")
graph = []
for i in range(n):
    row = list(map(int, input().split()))
    graph.append(row)

selected = [False] * n
selected[0] = True

print("Edge : Weight")

for _ in range(n - 1):
    min_val = 999
    x = y = 0

    for i in range(n):
        if selected[i]:
            for j in range(n):
                if not selected[j] and graph[i][j] != 0:
                    if graph[i][j] < min_val:
                        min_val = graph[i][j]
                        x = i
                        y = j

    print(x, "-", y, ":", graph[x][y])
    selected[y] = True