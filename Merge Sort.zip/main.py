#Write a  program to perform merge sort on the given teo lists o0f integer values.
# Merge two sorted lists (helper for merge sort)
def merge(left, right):
    result = []
    i = j = 0

    # Compare elements and merge
    while i < len(left) and j < len(right):
        if left[i] <= right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1
 
    # Add remaining elements
    result.extend(left[i:])
    result.extend(right[j:])
    return result


# Merge Sort function
def merge_sort(arr):
    if len(arr) <= 1:
        return arr

    mid = len(arr) // 2
    left = merge_sort(arr[:mid])
    right = merge_sort(arr[mid:])

    return merge(left, right)


# --- User Input ---
list1 = list(map(int, input("Enter first list of numbers: ").split()))
list2 = list(map(int, input("Enter second list of numbers: ").split()))

# Combine lists
combined_list = list1 + list2

# Sort combined list using merge sort
sorted_list = merge_sort(combined_list)

# Output
print("Sorted merged list:", sorted_list)