#Write a program to find solutiuon for knapsack problem using greedy algorithm.
def fractional_knapsack(values, weights, capacity):
    n = len(values)
    
    # Calculate value/weight ratio
    items = []
    for i in range(n):
        items.append((values[i], weights[i], values[i] / weights[i]))
    
    # Sort items by ratio in descending order
    items.sort(key=lambda x: x[2], reverse=True)
    
    total_value = 0.0
    
    for value, weight, ratio in items:
        if capacity >= weight:
            total_value += value
            capacity -= weight
        else:
            total_value += value * (capacity / weight)
            break
    
    return total_value


# --- User Input ---
n = int(input("Enter number of items: "))

values = list(map(int, input("Enter values: ").split()))
weights = list(map(int, input("Enter weights: ").split()))

capacity = int(input("Enter knapsack capacity: "))

# --- Function Call ---
max_value = fractional_knapsack(values, weights, capacity)

# --- Output ---
print("Maximum value in knapsack =", max_value)