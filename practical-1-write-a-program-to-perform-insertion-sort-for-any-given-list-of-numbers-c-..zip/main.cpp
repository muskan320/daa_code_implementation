// Write a program to perform Insertion sort for any given list of numbers.
#include <iostream>
using namespace std;
int main(){
    int n;
    int arr[100];
    
cout<<"Enter the number of elements:"<<endl;
cin>>n;

cout<<"Enter"<<" "<<n<<" "<<"element:"<<endl;
for(int i=0;i<n;i++){
 cin>>arr[i];
}
    
//Insertion sort
for( int i=1;i<n;i++)
{
    int key=arr[i];
    int j=i-1;
    
      
    
//for shifting and compairing
while(j>=0 && arr[j]>key){
    arr[j+1] = arr[j];
    j--;
    }
        arr[j+1]=key;
      } 
    cout<<"Sorted array:\n";
    for(int i=0;i<n;i++){
        cout<<arr[i]<<" ";
    }
    return 0;
    
    
    
}